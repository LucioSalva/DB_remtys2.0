# Contrato de integración — `remtys_db` ↔ Backend / Frontend

Este documento lista los puntos donde el backend y el frontend deben tomar
decisiones de integración. La base de datos NO los resuelve por sí sola.

---

## 1. Almacenamiento físico de archivos

La tabla `documento` guarda **metadatos**, no binarios:

- `sha256` (hash del archivo)
- `mime_type`
- `tamano_bytes`
- `url` (ruta o URL al binario)
- `vigencia_hasta`

**Backend debe decidir** dónde viven los PDFs:

- ✅ Recomendado: S3 / MinIO / Azure Blob.
- Aceptable: filesystem local con backup externo.
- No recomendado: `bytea` en la propia DB (no escala).

La columna `documento.url` debe quedar con la referencia.

---

## 2. Autenticación y usuarios

La DB **no tiene** tabla `usuario` ni roles. Asume que el backend identifica al
contribuyente por su `contribuyente.id`.

Si la Ventanilla Única ya tiene su propio identity provider (Keycloak, Auth0,
Azure AD, etc.):

- Mapear `contribuyente.id` ↔ ID externo.
- Si hace falta, agregar columna `contribuyente.external_id TEXT UNIQUE`
  (la DB la puede añadir si lo piden).

---

## 3. Antivirus / validación de upload

La DB no escanea archivos. Backend debe:

1. Recibir el archivo.
2. Pasar por antivirus (ClamAV o similar).
3. Calcular `sha256`.
4. Verificar dedupe: `SELECT * FROM documento WHERE contribuyente_id = ? AND sha256 = ?`.
5. Si no existe, subir al storage e insertar en `documento`.

---

## 4. Cálculo de `vigencia_hasta`

Hoy es campo libre. Backend debe definir la política:

- ¿La pone el contribuyente?
- ¿Una regla por `tipo_documento` (ej. recibo predial = ejercicio fiscal vigente)?
- ¿La pone el funcionario al validar?

Si quieren reglas en DB, se pueden agregar a `tipo_documento.vigencia_dias_default`
(el equipo DB lo puede sumar a petición).

---

## 5. Transiciones de estado de `solicitud`

Enum existente:

```
BORRADOR → EN_REVISION → APROBADA → CONCLUIDA
                       → RECHAZADA
```

Hoy **no hay trigger** que prohíba saltos inválidos (ej. `BORRADOR → CONCLUIDA`).

Decidir:

- Backend lo controla → DB se queda como está.
- Backend pide enforcement → equipo DB añade `trg_solicitud_estado_check`.

---

## 6. Auditoría

La DB no tiene columnas sistemáticas `created_at`, `updated_at`, `created_by`,
ni tabla de bitácora.

Si Ventanilla Única lo exige:

- Opción A: agregar las columnas a las tablas críticas.
- Opción B: tabla `audit_log` con triggers.

Cualquiera de las dos la implementa el equipo DB cuando se solicite.

---

## 7. Pagos

- `tramite.costo_monto` y `tramite.anticipo_pct` están como referencia.
- **No existe** tabla `pago` ni integración con pasarela.

Backend debe:

- Crear su propia tabla `pago` referenciando `solicitud_id`.
- Integrar pasarela (BBVA, OpenPay, etc.).
- Para T8 Convenio: validar que el anticipo del 20% (`tramite.anticipo_pct`)
  esté pagado antes de pasar `solicitud.estado` a `EN_REVISION`.

---

## 8. Roles administrativos

No hay modelo de "funcionario que aprueba/rechaza". Backend lo agrega en su
capa de autorización + tabla propia si la necesita.

---

## 9. OCR / autocompletado

El pipeline `ocr_pdfs.py` del repo procesa los **20 PDFs originales de las
fichas**, no documentos del contribuyente.

Si quieren autocompletar datos del documento subido (extraer CURP, RFC,
clave catastral, etc.), eso es trabajo del backend.

---

## 10. Endpoints sugeridos para backend

Solo como referencia, NO son obligatorios:

| Endpoint | Propósito | Tabla(s) principal(es) |
|---|---|---|
| `POST /contribuyentes` | Alta de contribuyente | `contribuyente` |
| `POST /documentos` | Subir documento (con dedupe) | `documento` |
| `GET /documentos/reutilizables` | Lo que ya tiene vigente | `v_documentos_reutilizables` |
| `POST /solicitudes` | Iniciar trámite | `solicitud` |
| `GET /solicitudes/{id}/checklist` | Qué falta | `v_solicitud_checklist` |
| `POST /solicitudes/{id}/documentos` | Vincular doc a solicitud | `solicitud_documento` |
| `PATCH /solicitudes/{id}/estado` | Cambiar estado | `solicitud` |

---

## 11. Lo que el equipo DB se compromete a hacer cuando lo pidan

- Agregar índices según los queries reales del backend (`EXPLAIN ANALYZE`).
- Añadir columnas/tablas faltantes (auditoría, external_id, etc.).
- Migraciones versionadas.
- Vistas adicionales para reportes.
- Soporte ante incidentes en producción.

---

## 12. Lo que NO va a hacer el equipo DB

- Almacenamiento de archivos.
- Autenticación.
- Pagos.
- Lógica de negocio que no pertenezca a integridad referencial.
- Frontend / UI.

---

**Versión del contrato:** 1.0 — 2026-04-27
