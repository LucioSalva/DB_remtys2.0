# Entrega `remtys_db` al equipo de Backend

Base de datos PostgreSQL 17 — repositorio documental único por contribuyente
para los 20 trámites de la Tesorería Municipal de Ecatepec.

Repositorio fuente: https://github.com/LucioSalva/DB_remtys2.0

---

## 1. Contenido de este paquete

```
entrega_backend/
├── README_BACKEND.md                 (este archivo)
├── CONTRATO_INTEGRACION.md           Puntos que back/front deben resolver
├── Resumen_remtys_db.docx            Resumen + flujo + diagrama
├── db/
│   ├── 01_schema.sql                 DDL completo
│   ├── 02_seed_catalogos.sql         32 tipo_documento + grupos
│   ├── 03_seed_tramites.sql          20 trámites
│   ├── 04_seed_requisitos.sql        309 requisitos base
│   ├── 05_patch_ajustes.sql          Ajustes idempotentes (→ 342 requisitos)
│   └── 99_validate.sql               Queries de verificación
└── backups/
    ├── remtys_db_*.dump              pg_dump -Fc (recomendado para restaurar)
    └── remtys_db_*.sql               pg_dump plain (texto legible)
```

---

## 2. Restaurar la base — opciones

### Opción A: desde el dump custom (recomendada)

```bash
# 1. Crear la base vacía
psql -U postgres -h localhost -p 5432 -c "CREATE DATABASE remtys_db;"

# 2. Restaurar
pg_restore -U postgres -h localhost -p 5432 -d remtys_db \
  --clean --if-exists --no-owner --no-privileges \
  backups/remtys_db_20260422_110826.dump
```

### Opción B: desde los scripts SQL paso a paso

```bash
psql -U postgres -h localhost -c "CREATE DATABASE remtys_db;"
psql -U postgres -d remtys_db -f db/01_schema.sql
psql -U postgres -d remtys_db -f db/02_seed_catalogos.sql
psql -U postgres -d remtys_db -f db/03_seed_tramites.sql
psql -U postgres -d remtys_db -f db/04_seed_requisitos.sql
psql -U postgres -d remtys_db -f db/05_patch_ajustes.sql
psql -U postgres -d remtys_db -f db/99_validate.sql
```

### Opción C: desde el dump plano

```bash
psql -U postgres -h localhost -c "CREATE DATABASE remtys_db;"
psql -U postgres -d remtys_db -f backups/remtys_db_20260422_110826.sql
```

---

## 3. Validar la restauración

Tras restaurar, deben aparecer:

| Métrica | Valor esperado |
|---|---|
| `tipo_documento` | 32 filas |
| `grupo_documento` | 2 filas (ACREDITA_PROPIEDAD, IDENT_O_RECIBO_PREDIAL) |
| `tramite` | 20 filas |
| `tramite_requisito` | 342 filas |
| `tramite.anticipo_pct` (T8 Convenio) | 20.00 |

Query rápido:

```sql
SELECT 'tipo_documento' AS t, count(*) FROM tipo_documento
UNION ALL SELECT 'grupo_documento', count(*) FROM grupo_documento
UNION ALL SELECT 'tramite', count(*) FROM tramite
UNION ALL SELECT 'tramite_requisito', count(*) FROM tramite_requisito;
```

---

## 4. Modelo en una línea

- **`contribuyente`** sube **`documento`** una sola vez (dedup por `sha256`).
- Cada **`tramite`** tiene una matriz de **`tramite_requisito`** por tipo de persona (FISICA / JURIDICA / INSTITUCION_PUBLICA).
- Una **`solicitud`** = un trámite iniciado por un contribuyente. La vista **`v_solicitud_checklist`** indica qué documentos faltan vs. cuáles se reutilizan.
- Un **trigger** valida que `documento.scope` (CONTRIBUYENTE / INMUEBLE / SOLICITUD) tenga la FK correcta.

Ver `Resumen_remtys_db.docx` para el diagrama de flujo completo.

---

## 5. Lo que NO incluye la DB (responsabilidad del backend)

Resumido en `CONTRATO_INTEGRACION.md`. Puntos clave:

- Almacenamiento físico de PDFs (S3/MinIO/FS).
- Autenticación y modelo de usuarios/roles.
- Antivirus en el upload.
- Pasarela de pagos.
- Validación de transiciones de estado de `solicitud` (si la quieren aplicada).
- Auditoría (`created_at`/`updated_at`/`created_by`).

---

## 6. Convenciones del esquema

- Naming: `snake_case`, singular para tablas (`contribuyente`, no `contribuyentes`).
- Enums: `tipo_persona`, `doc_scope`, `doc_estado`, `solicitud_estado`, `sol_doc_estado`, `area_responsable`.
- Claves foráneas: siempre `<tabla>_id`.
- Vistas: prefijo `v_`.
- Triggers: prefijo `trg_`.

---

## 7. Contacto

- Responsable DB: equipo de base de datos (este equipo).
- Repo: https://github.com/LucioSalva/DB_remtys2.0
- Versión PostgreSQL probada: **17** (Windows). Compatible con Linux 17.
